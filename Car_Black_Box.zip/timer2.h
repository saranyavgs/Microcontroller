#ifndef TIMER2_H
#define	TIMER2_H

void init_timer2(void);

#endif	/* TIMER2_H */

